# Contributing to the Somali AI/NLP Resource Registry

Thank you for helping make Somali AI and NLP resources easier to find. This registry records **metadata and links only**. Please read this page before submitting.

## Contents

- [What qualifies](#what-qualifies)
- [Required information](#required-information)
- [How to submit](#how-to-submit)
- [How submissions are verified](#how-submissions-are-verified)
- [Submitting corrections](#submitting-corrections)
- [Duplicates](#duplicates)
- [Why third-party datasets are not uploaded](#why-third-party-datasets-are-not-uploaded)

## What qualifies

An item can be added if all of the following hold.

1. **It is related to Somali.** Somali (language code `so`) is a substantive part of the resource: a Somali-only resource, or a multilingual resource in which the Somali portion can be identified (for example a Somali partition or a documented Somali subset). A multilingual model with no Somali-specific documentation does not qualify.
2. **It is AI or NLP related.** For example: text corpora, speech data, parallel text, annotated datasets, lexicons and terminology, language models, ASR/TTS/MT/OCR systems, benchmarks, evaluation sets, tokenizers, NLP tools and services.
3. **It is publicly documented in a retrievable authoritative source.** A paper or preprint, an official dataset or model page (Hugging Face, Zenodo, Mozilla Data Collective, a catalog such as LDC), an official code repository, or an institution's own project page. A social-media post, a news article about the resource, or a page that gives no scope, scale or intended use is not enough on its own.
4. **Access may be restricted.** Licensed, on-request, sample-only and not-yet-released resources are accepted, with their access status recorded accurately. Private resources with no public documentation are not.
5. **Research studies** that report Somali results but release no dataset or model may be recorded with `resource_type` set to `Research study` and status `Unavailable`, if the study is a substantial Somali-specific contribution. The maintainers may decline entries that are not Somali-specific.

Not accepted: material you cannot link to an authoritative source, resources whose only evidence is a secondary summary, and links to pirated or unauthorized copies of data.

## Required information

Every submission must provide:

| Required | Notes |
|---|---|
| Name | As given by the original source |
| Category and task | Choose from the allowed values in [`docs/SCHEMA.md`](docs/SCHEMA.md) |
| Short description | One or two factual sentences; no promotional language |
| Creator(s) | As listed by the source |
| Year | Year of release or publication; `Not reported` if the source gives none |
| Language and dialect | `Not reported` if the source does not say |
| Access status | Available, Restricted, On request, Sample only, Unreleased, Unavailable or Unknown |
| **Authoritative source URL** | The page you checked. At least one is required. |

Please also give, when the source states them: size, licence, institution, and the dataset, repository, Hugging Face, paper and documentation URLs.

Rules for filling fields:

- **Copy what the source says. Do not infer.** If the source does not state a licence or size, write `Not reported`.
- If you could not check something, write `Unknown`. If you only know it from a secondary source, write `Unverified`.
- Never guess a URL. If a link is dead, say so.

## How to submit

**Option A: GitHub issue (easiest).** Use the *New resource* issue form and fill in the fields.

**Option B: pull request.**

1. Fork the repository and edit `data/resources.csv`, adding one row at the end with the next free id (`SOMREG-023`, and so on). The template in [`templates/resource-entry-template.md`](templates/resource-entry-template.md) lists every field.
2. Run `python scripts/validate.py`. It must report `OK`.
3. Run `python scripts/generate_table.py` to refresh the README table.
4. Open a pull request using the template and tick the checklist.

By contributing you agree that your contribution to the metadata may be shared under the licences in the README.

## How submissions are verified

A maintainer opens the authoritative source you gave and compares each field with it. Fields that match are kept; fields that cannot be matched are marked `Unverified` or `Unknown`; fields that conflict with the source are corrected. The maintainer sets `verification` and `date_verified`. Entries stay marked `Partially verified` until every non-empty field has been checked. Details are in [`docs/VERIFICATION.md`](docs/VERIFICATION.md).

## Submitting corrections

Use the *Correction* issue form, name the entry id, say which field is wrong, and link the authoritative source that shows the correct value. Corrections are accepted only when backed by an authoritative source (a statement from the creators on their own page counts). Maintainers update the row and `date_verified`; the history stays in Git.

If a resource has moved, been renamed or withdrawn, or its licence has changed, report it the same way.

## Duplicates

- One entry per resource, not one per paper or mirror. A dataset and the paper that describes it are one entry; the paper goes in `paper_url`.
- Mirrors and forks of the same resource are mentioned in `notes`, not added as new entries.
- A new version with its own release page and licence may be a new entry; otherwise update the existing one and note the version.
- Pipelines that build a corpus from other corpora are one entry; their upstream sources are noted but not listed separately unless they are Somali resources in their own right.
- Before submitting, search `data/resources.csv` and `data/watchlist.csv` by name and by URL. The validator rejects duplicate ids, names and primary URLs.

## Why third-party datasets are not uploaded

The registry never stores or redistributes datasets, audio, text dumps or model weights that other people created, because:

1. **Licences and terms.** Many resources forbid redistribution or require an agreement (for example LDC packs, or datasets on Mozilla Data Collective that prohibit re-hosting without permission). Copies here could break those terms.
2. **People's data.** Speech and social-media datasets can contain personal data. Control should stay with the original custodians.
3. **Authority and freshness.** The creators' page is the place where corrections, withdrawals and updates appear. A copy would go stale and split the record.
4. **Size and cost.** An index stays small and easy to review.

Contributors submit metadata and links to the original location. Only material created explicitly for this registry project may be considered for hosting.

## Conduct

All participation is covered by the [Code of Conduct](CODE_OF_CONDUCT.md).
