# Resource submission template

Copy this into a new issue, or use it to fill one row of `data/resources.csv`. Write `Not reported`, `Unknown` or `Unverified` instead of guessing.

```
name:
category:                (see docs/SCHEMA.md)
task:
resource_type:
description:             (one or two factual sentences)
creator:
institution:
year:
language:
dialect:
size:                    (as stated by the source, with unit)
license:                 (as stated by the source)
access:
dataset_url:
repository_url:
huggingface_url:
paper_url:
documentation_url:
status:                  (Available / Restricted / On request / Sample only / Unreleased / Unavailable / Unknown)
source:                  (authoritative page(s) you checked)  <-- required
notes:
```

Checklist

- [ ] I checked the values against the authoritative source, not a summary of it.
- [ ] I did not guess any value or URL.
- [ ] I searched the registry for duplicates by name and URL.
- [ ] I am not uploading any dataset or model, only metadata and links.
