# Somali AI/NLP Resource Registry

A community-maintained catalog of publicly documented Somali AI and NLP resources.

This repository is a **registry (an index)**. It records structured metadata and links to the original, authoritative sources of Somali datasets, models, tools and studies, so that researchers, developers, students and institutions can find them. It does **not** host or redistribute any third-party dataset or model.

## Contents

- [Why this registry exists](#why-this-registry-exists)
- [Relationship to the research survey](#relationship-to-the-research-survey)
- [The initial 22 resources](#the-initial-22-resources)
- [Categories covered](#categories-covered)
- [How resources are verified](#how-resources-are-verified)
- [How to contribute](#how-to-contribute)
- [What this registry does not host](#what-this-registry-does-not-host)
- [Data format](#data-format)
- [How to cite](#how-to-cite)
- [Current limitations](#current-limitations)
- [License](#license)

## Why this registry exists

Somali resources for AI and NLP are scattered across preprint servers, Hugging Face, GitHub, university pages and licensed catalogs, and are documented to very different standards. Someone starting a Somali project currently has to rebuild the landscape from scratch. The registry gives each resource one record with its creators, scale, licence, access conditions and the link to the place where it is authoritatively described, plus a note on how well that information could be verified.

## Relationship to the research survey

The registry accompanies the survey *Mapping the Landscape of Artificial Intelligence and Natural Language Processing Resources for the Somali Language: A Survey of Datasets, Models, and Research Gaps* (Muad Mohamed Mohamud). The survey is a snapshot as of October 2026 and proposes a central resource registry as a recommendation; this repository is an implementation of that proposal.

- The initial entries (`SOMREG-001` to `SOMREG-022`) are the 22 resources counted in the survey's Sections 4.1 to 4.4. [`docs/survey-crosswalk.md`](docs/survey-crosswalk.md) maps each entry to the survey's citation.
- The survey's conclusions are not restated or changed here. Registry entries record verifiable facts about resources; interpretation and gap analysis stay in the survey.
- The survey's institutions section (4.5) and the forthcoming Thiomi dataset are not counted among the 22. They are tracked in [`data/watchlist.csv`](data/watchlist.csv) together with a few candidates found during verification.
- After publication of the survey the registry continues to change. Each entry carries the date it was last verified.

## The initial 22 resources

<!-- BEGIN:SUMMARY -->
<!-- END:SUMMARY -->

Access status describes what a visitor can do with the original source today. Verification states how fully the entry was checked against original sources (see below). The full records, including source URLs, are in [`data/resources.csv`](data/resources.csv).

<!-- BEGIN:TABLE -->
<!-- END:TABLE -->

Some entries are research studies without a released dataset or model (for example SOMREG-007, -008, -015, -018 and -021). They are included because the survey counted them; whether such entries meet the registry's inclusion criteria is described in [CONTRIBUTING.md](CONTRIBUTING.md#what-qualifies).

## Categories covered

<!-- BEGIN:CATEGORIES -->
<!-- END:CATEGORIES -->

The schema also allows language models, OCR, text-to-speech, conversational AI, lexicons and benchmarks. No entry exists yet in those categories, which reflects only what has been added so far and is not a statement that no such resources exist.

## How resources are verified

Every entry is checked against the original or authoritative source (a paper, an official dataset or model page, an official repository, a catalog record or an institutional page), not against secondary summaries. Each entry records:

- the `source` it was verified against,
- a `verification` level: **Verified**, **Partially verified** or **Unverified**,
- the `date_verified`.

Missing information is never filled in by guesswork:

| Value | Meaning |
|---|---|
| `Not reported` | The authoritative source was checked and does not state it. |
| `Unknown` | It could not be determined (source unavailable or not fully checked). |
| `Unverified` | A claim exists, for example in a secondary source, but could not be confirmed against a primary source. |

Dead links are recorded as such (status `Unavailable`, with a note), never replaced by a guessed link. The full method is in [`docs/VERIFICATION.md`](docs/VERIFICATION.md). The initial verification pass is written up in [`reports/initial-verification-2026-10.md`](reports/initial-verification-2026-10.md).

## How to contribute

Found a Somali AI or NLP resource that is not listed, or an error in an entry?

1. **New resource:** open an issue with the *New resource* form, or send a pull request that adds one row to `data/resources.csv`.
2. **Correction:** open an issue with the *Correction* form and link the authoritative source that shows the correct value.
3. **Broken link:** open an issue with the *Broken link* form.

An authoritative source is required for every submission. Read [CONTRIBUTING.md](CONTRIBUTING.md) first; it explains what qualifies, what information is required, how duplicates are handled and why datasets are never uploaded.

## What this registry does not host

- No third-party dataset, corpus, audio, model weights or scraped text is stored here, and none may be added.
- Entries contain metadata and links only. Where the original source restricts access or redistribution, that restriction is recorded in the entry and the registry points to the original location.
- The only material that could ever be hosted directly is material created explicitly for this registry project (for example its own metadata and schema).

## Data format

- [`data/resources.csv`](data/resources.csv): the registry, one row per resource.
- [`data/watchlist.csv`](data/watchlist.csv): items not yet in the registry (unreleased, institution-listed, or found but not fully reviewed).
- [`docs/SCHEMA.md`](docs/SCHEMA.md): field definitions and allowed values.
- `python scripts/validate.py` checks the CSV; the same check runs on every pull request.

## How to cite

Please cite the registry and, where relevant, the survey. See [`CITATION.cff`](CITATION.cff) for machine-readable metadata.

> Mohamud, M. M. (2026). *Somali AI/NLP Resource Registry* (Version 0.1.0) [Data set]. GitHub. URL to be added once the repository is published.

When you use a resource listed here, cite the resource's own paper or dataset page as given in its entry. The registry is an index and is not a substitute for citing the original work.

## Current limitations

- The inventory is not complete. It starts from a single researcher's English-language survey, so resources documented only in Somali, Arabic or on platforms outside the sources searched are likely missing.
- Entries were verified at one point in time. Licences, availability and links change; check `date_verified`.
- Several entries are only partially verified, because some pages were visible only as search-engine excerpts and some figures could not be matched to full texts. These are marked.
- Scale figures are reported as stated by the original sources and are not comparable across entries.
- Verification covers metadata, not data quality; the registry does not rate or benchmark resources.

## License

- Code and documentation: MIT, see [LICENSE](LICENSE).
- Registry metadata in `data/`: CC BY 4.0, see [`docs/DATA_LICENSE.md`](docs/DATA_LICENSE.md).

The licences of the listed resources belong to their creators and are stated in each entry as reported by the original source.
