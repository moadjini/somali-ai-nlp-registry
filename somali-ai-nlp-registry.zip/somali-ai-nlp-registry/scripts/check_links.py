#!/usr/bin/env python3
"""Report which URLs in data/resources.csv do not resolve. Read-only: it never edits the data.
Some sites block automated requests; treat failures as prompts to check by hand, not as proof."""
import csv, pathlib, urllib.request, urllib.error

ROOT = pathlib.Path(__file__).resolve().parent.parent
URL_FIELDS = ["dataset_url","repository_url","huggingface_url","paper_url","documentation_url"]

def check(url):
    req = urllib.request.Request(url, headers={"User-Agent": "somali-ai-nlp-registry-link-check"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception as e:
        return f"error: {type(e).__name__}"

seen = {}
for row in csv.DictReader(open(ROOT / "data" / "resources.csv", newline="", encoding="utf-8")):
    for f in URL_FIELDS:
        u = row[f].strip()
        if u and u not in seen:
            seen[u] = (row["id"], f)
bad = 0
for u, (i, f) in seen.items():
    s = check(u)
    ok = isinstance(s, int) and 200 <= s < 400
    bad += 0 if ok else 1
    print(("OK   " if ok else "FAIL ") + f"{i} {f} {s} {u}")
print(f"{len(seen) - bad} ok, {bad} to review")
