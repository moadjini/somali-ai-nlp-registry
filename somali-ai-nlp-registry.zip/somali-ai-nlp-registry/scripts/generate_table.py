#!/usr/bin/env python3
"""Regenerate the resource table and category counts in README.md from data/resources.csv.
Usage: python scripts/generate_table.py
Text between the BEGIN/END markers in README.md is replaced; nothing else is touched."""
import csv, pathlib, re, collections

ROOT = pathlib.Path(__file__).resolve().parent.parent
rows = list(csv.DictReader(open(ROOT / "data" / "resources.csv", newline="", encoding="utf-8")))

def link(row):
    for k in ("dataset_url", "huggingface_url", "repository_url", "paper_url", "documentation_url"):
        if row[k].strip():
            return row[k].strip()
    return ""

def esc(s):
    return s.replace("|", "\\|")

table = ["| ID | Resource | Category | Access status | Verification |", "|---|---|---|---|---|"]
for r in rows:
    u = link(r)
    name = f"[{esc(r['name'])}]({u})" if u else esc(r["name"])
    table.append(f"| {r['id']} | {name} | {esc(r['category'])} | {r['status']} | {r['verification']} |")

counts = collections.Counter(r["category"] for r in rows)
cat = ["| Category | Entries |", "|---|---|"] + [f"| {c} | {n} |" for c, n in counts.most_common()]
vcounts = collections.Counter(r["verification"] for r in rows)
summary = f"{len(rows)} entries: " + ", ".join(f"{n} {v.lower()}" for v, n in vcounts.most_common()) + "."

def sub(text, tag, body):
    pat = re.compile(rf"(<!-- BEGIN:{tag} -->\n).*?(\n<!-- END:{tag} -->)", re.S)
    return pat.sub(lambda m: m.group(1) + body + m.group(2), text)

p = ROOT / "README.md"
t = p.read_text(encoding="utf-8")
t = sub(t, "TABLE", "\n".join(table))
t = sub(t, "CATEGORIES", "\n".join(cat))
t = sub(t, "SUMMARY", summary)
p.write_text(t, encoding="utf-8")
print("README.md updated:", summary)
