#!/usr/bin/env python3
"""Validate data/resources.csv against docs/SCHEMA.md. Exit code 1 on any error."""
import csv, re, sys, pathlib
from urllib.parse import urlparse

ROOT = pathlib.Path(__file__).resolve().parent.parent
FIELDS = ["id","name","category","task","resource_type","description","creator","institution","year",
          "language","dialect","size","license","access","dataset_url","repository_url","huggingface_url",
          "paper_url","documentation_url","status","verification","source","date_verified","survey_section","notes"]
REQUIRED = ["id","name","category","task","description","creator","year","language","status","verification","source","date_verified"]
CATEGORIES = {"Text corpus","Speech / ASR","Machine translation","Sentiment & text classification","Language model",
              "OCR","Text-to-speech","Conversational AI","Lexicon & terminology","Benchmark","Other"}
STATUSES = {"Available","Restricted","On request","Sample only","Unreleased","Unavailable","Unknown"}
VERIFICATION = {"Verified","Partially verified","Unverified"}
URL_FIELDS = ["dataset_url","repository_url","huggingface_url","paper_url","documentation_url"]

def report(errors, n=0):
    if errors:
        print(f"{len(errors)} problem(s) found:")
        for e in errors:
            print(" -", e)
        return 1
    print(f"OK: {n} entries validated")
    return 0

def main():
    errors = []
    path = ROOT / "data" / "resources.csv"
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != FIELDS:
            errors.append(f"Header mismatch. Expected {FIELDS}, got {reader.fieldnames}")
            return report(errors)
        rows = list(reader)
    ids, names, urls = set(), {}, {}
    for n, row in enumerate(rows, start=2):
        tag = f"line {n} ({row['id'] or 'no id'})"
        for k in REQUIRED:
            if not row[k].strip():
                errors.append(f"{tag}: required field '{k}' is empty")
        if not re.fullmatch(r"SOMREG-\d{3,}", row["id"]):
            errors.append(f"{tag}: id must look like SOMREG-001")
        if row["id"] in ids:
            errors.append(f"{tag}: duplicate id")
        ids.add(row["id"])
        if row["category"] not in CATEGORIES:
            errors.append(f"{tag}: category '{row['category']}' not in allowed list")
        if row["status"] not in STATUSES:
            errors.append(f"{tag}: status '{row['status']}' not in allowed list")
        if row["verification"] not in VERIFICATION:
            errors.append(f"{tag}: verification '{row['verification']}' not in allowed list")
        if not re.match(r"^(\d{4}|Not reported|Unknown)", row["year"]):
            errors.append(f"{tag}: year must start with a 4-digit year, 'Not reported' or 'Unknown'")
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", row["date_verified"]):
            errors.append(f"{tag}: date_verified must be YYYY-MM-DD")
        for k in URL_FIELDS:
            u = row[k].strip()
            if u:
                p = urlparse(u)
                if p.scheme not in ("http", "https") or not p.netloc or " " in u:
                    errors.append(f"{tag}: {k} is not a valid http(s) URL")
                urls.setdefault((k, u), []).append(row["id"])
        key = re.sub(r"\W+", " ", row["name"].lower()).strip()
        if key in names:
            errors.append(f"{tag}: name duplicates {names[key]}")
        names[key] = row["id"]
        if row["verification"] == "Verified" and not row["source"].strip():
            errors.append(f"{tag}: verified entries need a source")
    for (k, u), who in urls.items():
        if k in ("dataset_url", "repository_url", "huggingface_url") and len(who) > 1:
            errors.append(f"duplicate {k} {u} used by {', '.join(who)} (merge entries or explain in notes)")
    return report(errors, len(rows))

if __name__ == "__main__":
    sys.exit(main())
