# Code of Conduct

## Our pledge

We want participation in this project to be respectful, welcoming and free of harassment for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, nationality, personal appearance, race, religion, clan or tribal affiliation, or sexual identity and orientation.

This is especially important for a Somali language project: Somali dialects and varieties (including Maxaa Tiri and Maay) and the people who speak them are all within scope, and none is treated as lesser.

## Expected behaviour

- Be respectful and constructive. Disagree with ideas, not people.
- Cite sources and be honest about uncertainty. Say "unverified" when something is unverified.
- Give credit to the creators of the resources you describe.
- Accept corrections graciously.

## Unacceptable behaviour

- Harassment, insults, threats, discriminatory language or personal attacks.
- Posting private information about others without permission.
- Promoting or linking to unauthorized copies of datasets, or to material that exposes personal data.
- Submitting deliberately false or misleading entries.
- Sustained disruption of discussions.

## Enforcement

Maintainers may edit or remove comments, issues, pull requests and entries that do not follow this Code, and may temporarily or permanently block contributors for behaviour they judge inappropriate. Maintainers will explain decisions when it is safe to do so.

## Reporting

Report concerns privately to the maintainers using the contact method listed in the repository's *Security* or *About* section. **[Maintainer contact to be added before publication.]**

## Scope and attribution

This Code applies in all project spaces (issues, pull requests, discussions) and when a person represents the project in public. It is adapted in spirit from the Contributor Covenant (https://www.contributor-covenant.org), but it is a shorter text written for this project.
