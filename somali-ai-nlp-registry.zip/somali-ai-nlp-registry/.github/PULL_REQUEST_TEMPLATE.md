## What does this pull request do?

- [ ] Adds a new resource (ids: )
- [ ] Corrects an existing entry (ids: )
- [ ] Documentation or tooling only

## Authoritative source(s) checked

<!-- Required for any change to data/. Paste the URLs of the pages you compared the values against. -->

## Checklist

- [ ] I compared every field I added or changed with the authoritative source.
- [ ] Unknown, unreported or unconfirmed values are written as `Unknown`, `Not reported` or `Unverified`, not guessed.
- [ ] No dataset, model, audio or text dump is included in this pull request, only metadata and links.
- [ ] I searched for duplicates by name and URL.
- [ ] `python scripts/validate.py` reports OK.
- [ ] `python scripts/generate_table.py` was run if rows changed.
