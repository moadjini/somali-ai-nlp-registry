# Registry schema

`data/resources.csv` is UTF-8, comma-separated, with one header row and one row per resource. Fields are in this order.

| Field | Required | Description |
|---|---|---|
| `id` | yes | `SOMREG-` plus a zero-padded number. Never reused. |
| `name` | yes | Name as given by the original source. |
| `category` | yes | One of: Text corpus; Speech / ASR; Machine translation; Sentiment & text classification; Language model; OCR; Text-to-speech; Conversational AI; Lexicon & terminology; Benchmark; Other. |
| `task` | yes | The AI/NLP task(s) the resource supports, as stated by the source. |
| `resource_type` | no | For example Corpus, Dataset, Model, Pipeline, Research study, Deployed service, Licensed corpus. |
| `description` | yes | One or two factual sentences. |
| `creator` | yes | Person(s) or organization(s) credited by the source. Semicolon-separated. |
| `institution` | no | Affiliation(s) stated by the source. |
| `year` | yes | Release or publication year. May carry a short qualifier. `Not reported` or `Unknown` if unavailable. |
| `language` | yes | Languages covered. |
| `dialect` | no | Dialect or variety if the source states one (for example Maxaa Tiri, Maay). |
| `size` | no | Scale as stated by the source, with its unit. Figures are not normalized. |
| `license` | no | Licence or terms as stated by the source. Use the source's wording; do not infer. |
| `access` | no | Free-text note on how the resource is obtained. |
| `dataset_url` | no | Authoritative download or landing page of a dataset. |
| `repository_url` | no | Official code repository. |
| `huggingface_url` | no | Official Hugging Face page. |
| `paper_url` | no | Paper, preprint or DOI link. |
| `documentation_url` | no | Documentation, catalog record or institutional page. |
| `status` | yes | Availability today: **Available**, **Restricted** (agreement or fee required), **On request**, **Sample only**, **Unreleased**, **Unavailable** (no release, or link dead), **Unknown**. |
| `verification` | yes | **Verified**, **Partially verified** or **Unverified**. See `docs/VERIFICATION.md`. |
| `source` | yes | What the entry was verified against (page names and identifiers). |
| `date_verified` | yes | `YYYY-MM-DD`. |
| `survey_section` | no | Section of the accompanying survey, if the entry came from it. |
| `notes` | no | Caveats, discrepancies between sources, access conditions. |

## Conventions

- **Empty URL field:** no such link was identified or verified. It is not a claim that none exists.
- **`Not reported`:** the authoritative source was checked and does not state the value.
- **`Unknown`:** the value could not be determined.
- **`Unverified`:** a claim exists but could not be confirmed against a primary source.
- A dead link is kept in the row, `status` is set to `Unavailable`, and `notes` records the date it failed. A guessed replacement is never entered.
- Multiple authors, institutions or licences are separated with semicolons.

## Validation

`python scripts/validate.py` checks the header, required fields, allowed values, id format, date and URL syntax, and duplicate ids, names and primary URLs. It does not check that links resolve; `python scripts/check_links.py` does that.
