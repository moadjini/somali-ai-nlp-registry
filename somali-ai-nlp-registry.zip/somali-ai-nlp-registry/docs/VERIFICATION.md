# How entries are verified

## Principle

The original source is authoritative. A paper, a survey, a blog post or this registry may summarize a resource, but when they disagree with the creators' own page, the creators' page wins, and the disagreement is recorded in `notes`.

## What counts as an authoritative source

In rough order of preference: the official dataset or model page (Hugging Face, Zenodo, Mozilla Data Collective, an LDC or ELRA catalog record); the official repository; the paper or preprint that introduces the resource; the creating institution's own project page. Secondary sources (aggregators, blogs, other papers that cite the resource) can help find the primary source but are not used to fill fields.

## Checks performed for each entry

1. Name, creators and institution match the source.
2. Year matches the release or publication record.
3. Category, task, language and dialect are as the source states them.
4. Size, with its unit, is as the source states it (estimates are labelled as estimates).
5. Licence and access terms are as the source states them.
6. Each URL points to the source it is claimed to be; availability is recorded.
7. Claims about the resource in other documents (such as the survey) are compared with the source and any difference is noted.

## Verification levels

- **Verified:** the fields that matter for finding and using the resource (identity, creators, year, scale, licence or terms, availability) were each matched to an authoritative source.
- **Partially verified:** the resource exists in an authoritative source but one or more fields could not be matched, or were checked only against an excerpt. The unchecked fields are named in `notes`.
- **Unverified:** the resource is known only from a secondary source.

## Re-verification

Entries should be re-checked at least yearly, and when a correction or broken-link report arrives. `python scripts/check_links.py` reports links that no longer resolve; it never edits the data.

## Reporting uncertainty

Uncertainty is stated, not hidden. Use `Unknown`, `Not reported` or `Unverified` as defined in `docs/SCHEMA.md`, and say in `notes` what would resolve the question.
