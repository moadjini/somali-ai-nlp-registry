# Survey crosswalk

The initial 22 entries are the resources counted in Sections 4.1 to 4.4 of the survey *Mapping the Landscape of Artificial Intelligence and Natural Language Processing Resources for the Somali Language* (Muad Mohamed Mohamud; snapshot October 2026). The survey counts them by primary task (its Figure 1). Items listed only in Section 4.5 (institutions) and the forthcoming Thiomi dataset are not counted and are in `data/watchlist.csv`.

| ID | Survey section | Survey citation |
|---|---|---|
| SOMREG-001 | 4.1 | Dahir (2026) |
| SOMREG-002 | 4.1 | Jama (n.d.) |
| SOMREG-003 | 4.1 | SomNLP-Corpus contributors (n.d.) |
| SOMREG-004 | 4.1 | Conneau et al. (2020) |
| SOMREG-005 | 4.1 | Mohamed et al. (2025) |
| SOMREG-006 | 4.1 | Badel et al. (2023) |
| SOMREG-007 | 4.2 | Menon et al. (2018) |
| SOMREG-008 | 4.2 | Biswas et al. (2019) |
| SOMREG-009 | 4.2 | Linguistic Data Consortium (2024) |
| SOMREG-010 | 4.2 | Digital Divide Data (n.d.) |
| SOMREG-011 | 4.2 | Ogaal Labs (n.d.) |
| SOMREG-012 | 4.2 | Ali (2026) |
| SOMREG-013 | 4.3 | tufaax (n.d.) |
| SOMREG-014 | 4.3 | Mutisya et al. (2026) |
| SOMREG-015 | 4.3 | Kuwanto et al. (2021) |
| SOMREG-016 | 4.3 | planwise-data (n.d.) |
| SOMREG-017 | 4.3 | Jamhuriya University of Science and Technology (n.d.-a) |
| SOMREG-018 | 4.4 | Abdirahman et al. (2023) |
| SOMREG-019 | 4.4 | SIMAD University AI Lab (n.d.) |
| SOMREG-020 | 4.4 | Mohamed et al. (2025) |
| SOMREG-021 | 4.4 | Ahmad et al. (2025) |
| SOMREG-022 | 4.4 | Gedi et al. (2026) |

Section 4.1: 6 entries; 4.2: 6; 4.3: 5; 4.4: 5; total 22. SOMREG-005 and SOMREG-020 come from the same paper (Mohamed et al., 2025) and are separate entries because the survey counts the pretraining corpus and the annotated datasets separately.
