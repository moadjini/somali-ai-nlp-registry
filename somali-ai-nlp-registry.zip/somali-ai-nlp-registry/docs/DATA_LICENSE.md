# Licence of the registry metadata

The files in `data/` (the registry metadata: field values, descriptions and notes written for this registry) are released under the **Creative Commons Attribution 4.0 International** licence (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/

Code in `scripts/` and the documentation are under the MIT licence (see `LICENSE`).

This licence applies only to the registry's own metadata. It does not apply to, and gives no rights in, the resources the registry describes. Each listed resource remains under the licence and terms stated by its creators, as recorded in the entry's `license` field.
